# Docker Configuration

🐳 Docker configurations cho Remote Control System.

## TODO

Khi cần deploy production:

- [ ] Dockerfile cho RemoteControl.Web
- [ ] Dockerfile cho RemoteControl.Agent
- [ ] docker-compose.yml
- [ ] nginx configuration
- [ ] .dockerignore

## Ghi chú

Hiện tại chưa cần thiết. Sẽ triển khai khi có nhu cầu containerization.
