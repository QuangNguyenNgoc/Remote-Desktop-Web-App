# Issue #30: [FE] Dashboard Analytics & Statistics

### 🎯 Mục Tiêu

Thêm statistics và analytics vào Dashboard (Home page)

### ✅ Checklist

**Real-time Stats Cards:**
- [ ] Tổng số agents connected
- [ ] Số agents online/offline
- [ ] Số commands đã thực thi (session)
- [ ] Uptime của server

**Charts (sử dụng Chart.js hoặc similar):**
- [ ] Line chart: Số agents theo thời gian (24h)
- [ ] Pie chart: Phân bố OS versions
- [ ] Bar chart: Commands frequency

**Activity Log:**
- [ ] Recent activities list (real-time)
- [ ] Filter by type (connect, disconnect, command)
- [ ] Click để xem chi tiết

**Agent Map (Optional - Advanced):**
- [ ] Hiển thị agents trên map (nếu có geolocation)

### 🔗 Dependencies

- ⏳ #13: DeviceManager hiển thị agents
- Library: Chart.js hoặc ApexCharts

### 📝 Design Mockup

```
┌─────────────────────────────────────────────────────────────┐
│  📊 Dashboard                                               │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐    │
│  │ 12       │  │ 8        │  │ 4        │  │ 156      │    │
│  │ Total    │  │ Online   │  │ Offline  │  │ Commands │    │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘    │
│                                                             │
│  ┌─────────────────────────┐  ┌─────────────────────────┐  │
│  │ Agents Over Time        │  │ OS Distribution         │  │
│  │        ___/\___         │  │     ████ Win11 (60%)    │  │
│  │   ___/        \___      │  │     ██ Win10 (30%)      │  │
│  └─────────────────────────┘  └─────────────────────────┘  │
│                                                             │
│  Recent Activity                                            │
│  ├─ 10:30 Agent PC-001 connected                           │
│  ├─ 10:28 Screenshot captured from DEV-WS                  │
│  └─ 10:25 Agent SERVER-01 disconnected                     │
└─────────────────────────────────────────────────────────────┘
```
